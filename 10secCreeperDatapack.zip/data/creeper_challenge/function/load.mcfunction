scoreboard objectives add creeper_timer dummy
scoreboard players add @a creeper_timer 0
