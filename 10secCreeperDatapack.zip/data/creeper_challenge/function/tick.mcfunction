scoreboard players add @a creeper_timer 1
execute as @a[scores={creeper_timer=200..}] at @s run summon minecraft:creeper ~ ~ ~
execute as @a[scores={creeper_timer=200..}] run scoreboard players set @s creeper_timer 0
